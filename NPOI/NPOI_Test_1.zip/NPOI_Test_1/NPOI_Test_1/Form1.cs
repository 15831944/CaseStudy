﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;

namespace NPOI_Test_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Test_Click(object sender, EventArgs e)
        {
            //创建一个新的Excel文件的workbook对象
            HSSFWorkbook wb = new HSSFWorkbook();
            //FileStream file;
            //string filepath = @"D:\测试NPOI.xls";
            //file =new FileStream(filepath,FileMode.Open,FileAccess.Read);
            //wb=new HSSFWorkbook(file);
            //file.Close();
            //在当前wb中创建一个名为sheet1的新的sheet页
            //ISheet sheet = new ISheet();
           // HSSFSheet sheet = new HSSFSheet();
            ISheet sheet = wb.CreateSheet("Sheet1");
            int num = 0;
            for (int i = 0; i < 4; i++)
            {
                sheet.CreateRow(i);//创建i行
                for (int j = 0; j < 4; j++)
                {
                    ICell cell1 = sheet.GetRow(i).CreateCell(j);//在i某一行创建j列
//                     cell1.SetCellValue(num);
//                     num++;
                }
            }

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    ICell cell1 = sheet.GetRow(i).GetCell(j);
                    cell1.SetCellValue(num);
                    num++;
                }
            }
            sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 1));
            //D:\\测试NPOI_1.xls
            FileStream sw = File.Create("D:\\测试NPOI_5.xls");
           // file = new FileStream(filepath, FileMode.Open, FileAccess.Write);
            wb.Write(sw);
            sw.Close();
            wb.Close();

        }
    }
}
